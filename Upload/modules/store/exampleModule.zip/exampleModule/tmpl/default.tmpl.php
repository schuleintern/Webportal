<div class="box">
	<div class="box-body">
		<div id=app>Hier der Content</div>
	</div>
</div>