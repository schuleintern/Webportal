module.exports = {
  filenameHashing: false
}