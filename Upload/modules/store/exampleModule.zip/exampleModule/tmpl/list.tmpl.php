<div class="box">
	<div class="box-body">
		<div id=app>Hier die Liste</div>
	</div>
</div>