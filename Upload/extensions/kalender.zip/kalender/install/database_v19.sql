
ALTER TABLE `ext_kalender` ADD `admins` VARCHAR(500)  DEFAULT NULL  AFTER `icsfeed`;
