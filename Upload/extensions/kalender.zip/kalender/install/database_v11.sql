
ALTER TABLE `ext_kalender_events` ADD `status` TINYINT  NULL  DEFAULT 0  AFTER `id`;
