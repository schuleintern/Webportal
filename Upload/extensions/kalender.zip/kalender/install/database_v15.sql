
ALTER TABLE `ext_kalender` ADD `icsfeed` VARCHAR(255)  DEFAULT NULL  AFTER `public`;
